/*******Author Name: sri vani bobbili  Emp Id : 150682 Date: 7/5/2018 ******/
//Purpose: To provide data validation for the user input


package com.dthoperator.service;

import com.dthoperator.exception.OperatorException;


public class RechargeDataValidator {
	//validating operator - it should be Airtel or DishTV or Reliance or TATAsky
	public static boolean validatedthOperator(String dthOperator)throws OperatorException
	{
		if(dthOperator.equalsIgnoreCase("AIRTEL") || dthOperator.equalsIgnoreCase("DISHTV") || dthOperator.equalsIgnoreCase("RELIANCE") || dthOperator.equalsIgnoreCase("TATASKY"))
		{
			return true;
		}
		else
		{
			// TODO Auto-generated method stub
			throw new OperatorException("Invalid dthOperator selection");
		}
	}
	//validating consumerNo with operator- consumnerNo should have only 10 digits and user given consumerNo should belong to respective operator
	public static boolean validateConsumerNo(String consumerNo,String operator)throws OperatorException {
		
		if((consumerNo.length() == 10) && (operator.equalsIgnoreCase("Airtel")) && (consumerNo.equals("8234567891") || consumerNo.equals("8234567899") ||consumerNo.equals("8234567898")))
		{
			return true;
		}
		else if((consumerNo.length() == 10) && (operator.equalsIgnoreCase("Reliance")) && (consumerNo.equals("8234567881") || consumerNo.equals("8234567889") ||consumerNo.equals("8234567888")))
		{
			return true;
		}
		else if((consumerNo.length() == 10) && (operator.equalsIgnoreCase("DishTV")) && (consumerNo.equals("9234567881") || consumerNo.equals("9234567889") ||consumerNo.equals("9234567888")))
		{
			return true;
		}
		else if((consumerNo.length() == 10) && (operator.equalsIgnoreCase("TATAsky")) && (consumerNo.equals("9134567881") || consumerNo.equals("9134567889") ||consumerNo.equals("9134567888")))
		{
			return true;
		}
		else
		{
			// TODO Auto-generated method stub
			throw new OperatorException("ConsumerNumber should only a 10-digit number or Invalid ConsumerNo for selected Operator");
		}
	}
	//validating plan - it should be MONTHLY or QUATERLY or RELIANCE or TATASKY
	public static boolean validatePlan(String plan)throws OperatorException {
		if(plan.equalsIgnoreCase("MONTHLY") || plan.equalsIgnoreCase("QUATERLY") || plan.equalsIgnoreCase("YEARLY") || plan.equalsIgnoreCase("ANNUAL"))
		{
			return true;
		}
		else
		{
			// TODO Auto-generated method stub
			throw new OperatorException("Invalid plan selection");
		}
	}
	//validating amount - it should contain minimum 3digit and max-4 digit number
	public static boolean validateAmount(int amount)throws OperatorException {
		if(amount > 99 && amount < 10000)
		{
			return true;
		}
		else
		{	
			// TODO Auto-generated method stub
			throw new OperatorException("Amount should be minimum 3-digit and max 4-digit number.");
		}
	}

}
