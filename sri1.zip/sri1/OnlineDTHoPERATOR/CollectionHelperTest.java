/*******Author Name: sri vani bobbili  Emp Id : 150682 Date: 7/5/2018 ******/
//Purpose: To provide test cases of OnlineDTHRecharge Application
package com.dthoperator.junit;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.exception.OperatorException;
import com.dthoperator.service.RechargeCollectionHelper;

@SuppressWarnings("deprecation")
public class CollectionHelperTest {

	static RechargeCollectionHelper collectionHelper;
	static RechargeDetails all=null;

	//adding asset details to the array list
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new  RechargeCollectionHelper();
		all=new  RechargeDetails("Airtel","1089343431","Monthly", 210, 4567);		
	}
	
	//clearing the array list
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		all=null;
	}	
	
	//checking whether asset details are present in array list
	@Test 
	public void testAddNewOperator() throws OperatorException
	{
		collectionHelper.addDetails(all);
		Assert.assertNotNull(all.gettransId());
	}

}
