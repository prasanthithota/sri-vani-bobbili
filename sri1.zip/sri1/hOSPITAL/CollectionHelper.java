package com.cg.librarymgmt.helper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;




public class CollectionHelper {

	private static ArrayList<PatientDetails> patientlist = null;
	static
	{
		patientlist = new ArrayList<PatientDetails>();
		//String fever = null;
		PatientDetails pd1 = new PatientDetails("chandu", "9652392359", "23", "fever", LocalDate.now(), 888088);
		//String cold = null;
		PatientDetails pd2 = new PatientDetails("hari", "9949882761", "23", "cold", LocalDate.now(), 888089);
		 patientlist.add(pd1);
		 patientlist.add(pd2);
	}
	public CollectionHelper(){}

	

	public static void addNewPatientDetails1(PatientDetails PatientDetails ) {
		// TODO Auto-generated method stub
		patientlist.add(PatientDetails);
		
	}
	public static ArrayList<PatientDetails> getpatientList() {
		return patientlist ;
	}
	public static void setpatientList(ArrayList<PatientDetails> patientList) {
		CollectionHelper.patientlist = patientList;
	}

	public static void addNewPatientDetails(PatientDetails pd) {
		// TODO Auto-generated method stub
		patientlist.add(pd);
		
	}
	public static void displayAllpatients()
	{
		Iterator<PatientDetails> patientIt=patientlist.iterator();
		PatientDetails temppatient=null;
		while(patientIt.hasNext())
		{
			temppatient=patientIt.next();
			System.out.println(temppatient);			
		}
	}
}