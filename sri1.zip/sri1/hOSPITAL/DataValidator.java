package com.cg.librarymgmt.helper;
import java.util.regex.Pattern;

import com.cg.hospitalmanagement.Exception.PatientException;
public class DataValidator {
	
	//validating Patient name - it should be alphanumeric and minimum 5 characters and maximum 15 
			public  static  boolean validateName(String assetName)throws PatientException
			{
				String asspattern="[A-Za-z]{5,15}";
				if(Pattern.matches(asspattern, assetName))
				{
					return true;
				}
				else
				{
					throw new  PatientException();
				}
			}
			public  static  boolean validateAge(String age)throws PatientException
			{
				String Agepattern="[0-9]{2}";
				if(Pattern.matches(Agepattern, age))
				{
					return true;
				}
				else
				{
					throw new  PatientException();
				}
			}
			public  static  boolean validatePhonenumber(String PatientNumber)throws PatientException
			{
				String Phonepattern="[7-9]{1}[0-9]{9}";
				if(Pattern.matches(Phonepattern, PatientNumber))
				{
					return true;
				}
				else
				{
					throw new  PatientException();
				}
			}
			public  static  boolean validateDesc(String PatientDesc) throws PatientException
			{
				String DescPattern ="[A-Za-z]{40}";
				if(Pattern.matches(DescPattern, PatientDesc))
				{
					return true;
				}
				else
				{
					throw new  PatientException();
				}
			}

}
