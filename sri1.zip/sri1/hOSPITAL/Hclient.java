
import java.util.Random;

import java.util.Scanner;

import com.cg.librarymgmt.helper.CollectionHelper;
import com.cg.librarymgmt.helper.DataValidator;
import com.cg.librarymgmt.helper.PatientDetails;

public class Hclient {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		//object r1;
		// TODO Auto-generated method stub
		String choice;
		while(true)
		{
			System.out.println("Hospital Management \n***************** \n1. Add patient Information\n"
					+ "2. Search patient by ID\n" + "3.Exit\n");
			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{
		    	//Calling addPatientDetails method for adding Patient details 
				case "1": addPatientkDetails();
				break;
				
				case "2":System.out.println("Enter the id");
				//object r11 = null;
				//int id = sc.nextInt();
					//searchById(id);
				break;
				case "3":System.out.println("Exiting...");
				System.exit(0);
				default: System.out.println("Please enter correct choice");
				break;
			}
			
		}
	}
	//method for adding patient details
		private static void addPatientkDetails() 
		{
			System.out.println("Enter the name of Patient: ");
			String PatientName = sc.next();
			try{
					//sending data to validateName method to validate name
					if(DataValidator.validateName(PatientName))
					{
						System.out.println("Enter the Patient Age: ");
						String PatientAge =sc.next();
						if(DataValidator.validateAge(PatientAge))
						{
							System.out.println("Enter Patient Phone Numbeer: ");
							String PatientNumber =sc.next();
							if(DataValidator.validatePhonenumber(PatientNumber))
							{
								System.out.println("Enter Description: ");
								String PatienDesc =sc.next();
								if(DataValidator.validateDesc(PatienDesc))
								{
									Random ran = new Random();
									long refId = ran.nextInt();
									 PatientDetails pd = new PatientDetails(PatientName,PatientNumber,PatientAge,PatienDesc,java.time.LocalDate.now(),refId);
									CollectionHelper.addNewPatientDetails(pd);
									//CollectionHelper.addNewPatientDetails();
									
									CollectionHelper.displayAllpatients();
								}
							}
						}
					}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
}
