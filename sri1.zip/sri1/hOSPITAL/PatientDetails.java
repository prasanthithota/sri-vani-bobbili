package com.cg.librarymgmt.helper;

import java.time.LocalDate;

public class PatientDetails {

	private String PatientName;
	private String PatientAge;
	private String PatientNumber;
	private String PatientDesc;
	private long referenceId;
	private LocalDate currentDate;
	
	public PatientDetails()
	{
		
	}
	public PatientDetails(String PatientName, String PatientAge, String PatientNumber, String PatientDesc, LocalDate currentDate, long referenceId )
	{
		this.PatientName = PatientName;
		this.PatientAge = PatientAge;
		this.PatientNumber = PatientNumber;
		this.PatientDesc = PatientDesc;
		this.currentDate = currentDate;
		this.referenceId = referenceId;
	}
	//getter for reference id
	public long getReferenceId() 
	{
		return referenceId;
	}
	//setter for reference id
	public void setReferenceId(int referenceId)
	{
		this.referenceId = referenceId;
	}
	//setter for current date
	public LocalDate getCurrentDate()
	{
		return currentDate;
	}
	//setter for current date
	public void setCurrentDate(LocalDate currentDate)
	{
		this.currentDate = currentDate;
	}	
	//getter for Patient name
	public String getPaientName()
	{
		return PatientName;
	}
	//setter for Patient age
	public void setPatientAge1(String PatientAge)
	{
		this.PatientAge = PatientAge;
	}
	public String getPatientAge()
	{
		return PatientAge;
	}
	//setter for Patient age
	public void setPatientAge(String PatientAge)
	{
		this.PatientAge = PatientAge;
	}
	public String getPatientNumber()
	{
		return PatientNumber;
	}
	//setter for Patient Number
	public void setPatientNumber(String PatientNumber)
	{
		this.PatientNumber = PatientNumber;
	}
	public String getPatientDesc()
	{
		return PatientDesc;
	}
	//setter for Patient Description
	public void setPatientDesc(String PatientDesc)
	{
		this.PatientDesc = PatientDesc;
	}
	@Override
	public String toString() {
		return " [Reference Id=" + referenceId + ", Patient Name="
				+ PatientName + ", Patient Age=" + PatientAge +", PatientDesc  =" + PatientDesc + " ,PatientNumber=" + PatientNumber
				+ ", Entry Date=" + currentDate + "]";
}
}
