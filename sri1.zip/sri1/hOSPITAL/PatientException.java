package com.cg.hospitalmanagement.Exception;

public class PatientException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public PatientException()
	{
		super();
	}
}
